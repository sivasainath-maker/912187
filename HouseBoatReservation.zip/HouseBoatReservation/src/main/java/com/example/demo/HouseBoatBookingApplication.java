package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
//Use appropriate annotation to scan the packages
public class HouseBoatBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HouseBoatBookingApplication.class, args);
	}

}
