package com.service;

import com.model.HouseBoatBean;
//use appropriate annotation to configure HouseBoatService as a Service
public class HouseBoatService {
	
	
	public double calculateTotalCost(HouseBoatBean houseBoatBean)
	{
		
		return 0.0;
		
		
	}

}
	 	  	    	    	     	      	 	
