package com.controller;


import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.model.HouseBoatBean;

//use appropriate annotation to configure RoomController as Controller

public class HouseBoatController {

	//invoke the service class - calculateTotalCost method.
	public String calculateTotalCost(@ModelAttribute("houseBoat") HouseBoatBean houseBoatBean,
			BindingResult result, ModelMap map) {

		return null;
	}

}
